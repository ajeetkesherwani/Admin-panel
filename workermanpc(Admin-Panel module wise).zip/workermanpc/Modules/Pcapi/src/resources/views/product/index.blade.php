<x-app-layout>

    <div class="container-fluid">
        <div class="layout-specing">

            <div class="row ">
                <div class="col-md-12 col-lg-12 my-0 lead_list">
                    <div class="pb-1">
                        <div class=" border-0 quotation_form">
                            <div
                                class="card-header py-3 bg-transparent d-flex align-items-center justify-content-between">
                                <h5 class="tx-uppercase tx-semibold mb-0">
                                    @if(!empty($proTitle))
                                        {{$proTitle->categories_name}}
                                    @else
                                        Product List
                                    @endif
                                </h5>
                            </div>
                        </div>
                        <!-- searchbar -->
                        <form action="{{route('search-products')}}" method="post">
                            @csrf
                            <div class="row mt-3 mb-3" id="search">
                                <div class="col-sm-3">
                                    <div class="search-form">
                                        <input type="search" name="search" id="searchbar" class="form-control" placeholder="Search Here">
                                        <button class="btn" id="searchBtn" type="submit"><i data-feather="search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!------ End searchbar ---->

                        {{-- <form action="{{route('search-products')}}" method="post">
                            @csrf
                            <div class="row" id="search">
                                <div class="col-sm-3 d-flex">
                                    <input type="text" id="searchbar" class="form-control" placeholder="Search Here" name="search" aria-label="Search" />
                                    <button type="submit" class="btn btn-primary btn-sm" id="searchBtn"><i class="uil uil-search"></i></button>
                                </div>
                            </div>
                        </form> --}}
                        
                        <div class="mt-1">
                            <div class="table-responsive" id="customer_table">
                                <!-- Start table -->
                                <table class="table table-center bg-white mb-0">
                                    <thead>
                                        <tr>
                                        <th class="border-bottom col-sm-1">
                                                    {{__('common.sl_no')}}</th>
                                                <th class="border-bottom col-sm-1">
                                                    Product Model</th>
                                                 <th class="border-bottom col-sm-2">
                                                    Product Name</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    Sort Order</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    {{__('common.status')}}</th>
                                                <th class="text-center border-bottom col-sm-1">
                                                    {{__('common.action')}}
                                                </th>
                                        </tr>
                                    </thead>
                                    <tbody id="table">
                                        @if(!empty($product_list))
                                        @foreach($product_list as $key=>$product)
                                        <tr>
                                            <td class="text-left ">{{$key+1}}</td>
                                            <td class="text-left "> {{$product->products_model}}
                                               </td>
                                           
                                            <td class="text-left ">  @if (!empty($product->productdescription))
                                                  {{ $product->productdescription[0]->products_name }}
                                                    @endif</td>
                                            
                                            <td class="text-center">
                                                <input type="number" class="col-xs-1 inputPassword2 width1" data-id="{{$product->products_id}}"  placeholder="" value="{{$product->sort_order}}" style="width:50px;">
                                            </td>
                                            <th scope="col" class="text-center">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input toggle-class"  {{ $product->isavailabel=="Yes" ? 'checked' : '' }} data-id="{{$product->products_id}}"  id="customSwitch{{$product->products_id}}">
                                                    <label class="custom-control-label" for="customSwitch{{$product->products_id}}"></label>
                                                </div>

                                                {{-- <input data-id="{{$product->products_id}}" class="form-check-input toggle-class mx-auto mt-2" type="checkbox" data-toggle="toggle" data-on="Active" style="display:block;" data-off="InActive" {{ $product->isavailabel=="Yes" ? 'checked' : '' }}> --}}
                                          </th>
                                            <td class="align-items-center justify-content-center d-flex">
                                                <a href="#" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-sm-inline mg-l-5"></span></a>
                                                <a href="#" id="website_delete_btn" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="repeat"></i><span class="d-none d-sm-inline mg-l-5"></span></a>


                                                {{-- <a class="btn btn-primary" href="#" role="button"><i class="uil uil-eye"></i></a>
                                                <a class="btn btn-primary" href="#" role="button"><i class="uil uil-shopping-cart"></i></a> --}}
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table><!-- end table -->
                            </div>
                            <div class="row text-center px-2">
                                <!-- PAGINATION START -->
                                <div class="col-12 mt-4">
                                    <div class="d-md-flex align-items-center text-center justify-content-between">
                                        <span class="text-muted me-3">Showing {{$product_list->currentPage();}} - {{$product_list->lastItem();}} out of {{$product_list->total()}}</span>
                                        <ul class="pagination mb-0 justify-content-center mt-4 mt-sm-0">
                                            {{ $product_list->links() }}
                                        </ul>
                                    </div>
                                </div>
                                    <!-- PAGINATION END -->
                            </div><!--end row-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!--start delete modal-->
<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <h5>Are you sure want to delete ?</h5>
            <input type="hidden" id="delete_department_id" name="input_field_id">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
            <button type="submit" class="btn btn-primary delete_submit_btn">Yes</button>
        </div>
    </div>
</div>
</div>
<!--end delete modal-->
    @push('scripts')
    <script>
        $(document).ready(function() {

            $(document).on("click", "#delete_btn", function() {
                var customer_id = $(this).val();
                $('#delete_department_id').val(customer_id);
                $('#delete_modal').modal('show');
            });
            $(document).on('click', '.delete_submit_btn', function() {
                var customer_id = $('#delete_department_id').val();

                $('#delete_modal').modal('show');

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                 
                $.ajax({
                    type: "POST",
                    // url: "{{ url('departmentDestroy') }}/" + department_id,
                    url : "{{ url('customer')}}/"+customer_id,
                    data: {
                        customer_id: customer_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        Toaster(response.success);
                        $('#delete_modal').modal('hide');
                        $('.flash-message').html(response.success);
                        $('.flash-message').addClass('alert alert-success');
                        $('#department_edit').modal('hide');
                        $("#customer_table").load(location.href + " #customer_table");
                        
                        $('.flash-message').fadeOut(3000, function() {
                            location.reload(true);
                        });
                    }
                });

            });

            // Product status toggle button jquery
            $('.toggle-class').change(function () {
            let status = $(this).prop('checked') === true ? 1 : 0; 
            console.log(status);
            let products_id = $(this).data('id');
            console.log(products_id);
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{url('pchangeStatus')}}",
                data: {'status': status, 'products_id': products_id},
                success: function (data) {
                    Toaster(data.success);
                    }
                });
            });

            // product sort order update
            $(".inputPassword2").on("blur",function(e){ 
                e.preventDefault();
                var products_id = $(this).data('id');
                var sort_order = $(this).val();
                console.log(products_id);
                console.log(sort_order);
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type:"POST",
                    url: "{{route('pSortOrder')}}",
                    data:{products_id:products_id,sort_order:sort_order},
                    dataType:"json",
                    success:function(data){
                        Toaster(data.success);
                    }
                }); 
            }); 
        });
        
    </script>
    <!--end delete ajax-->

    <script>
        //searchbar ajax
    //     $(document).ready(function(){
    //     $("#searchbar").on("keyup", function() {
    //         var value = $(this).val().toLowerCase();
    //         $("#table tr").filter(function() {
    //         $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    //     });
    //     });
    // });

    </script>
    @endpush
</x-app-layout>