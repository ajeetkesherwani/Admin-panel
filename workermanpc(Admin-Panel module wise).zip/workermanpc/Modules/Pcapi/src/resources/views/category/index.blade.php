<x-app-layout>

    <div class="container-fluid">
        <div class="layout-specing">
            <div class="row ">
                <div class="col-md-12 col-lg-12 my-0 lead_list">
                    <div class="pb-1">
                        <div class=" border-0 quotation_form">
                            <div class="card-header py-3 bg-transparent d-flex align-items-center justify-content-between">
                                <h5 class="tx-uppercase tx-semibold mb-0"> 
                                    @if(!empty($parentData))
                                        {{$parentData->categories_name}}
                                    @else 
                                        Category List
                                    @endif
                                </h5>
                              
                            </div>
                        </div>
                        <!-- searchbar -->
                        <form action="{{route('search-categories')}}" method="post">
                            @csrf
                            <div class="row mt-3 mb-3" id="search">
                                <div class="col-sm-3">
                                    <div class="search-form">
                                        @if(!empty($parentData))
                                            <input type="hidden" name="parentId" value="{{$parentData->categories_id}}">
                                        @endif
                                        <input type="search" name="search" id="searchbar" class="form-control" placeholder="Search Here">
                                        <button class="btn" id="searchBtn" type="submit"><i data-feather="search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                        <!-- end searchbar -->
                        <div class="mt-1">
                            <div class="table-responsive rounded " id="customer_table">
                                <!-- Start table -->
                                <table class="table table-center bg-white mb-0">
                                    <thead>
                                        <tr>
                                                <th class="border-bottom col-sm-1">
                                                    {{__('common.sl_no')}}</th>
                                                <th class="border-bottom col-sm-1">
                                                    Category Name</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    Sort Order</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    {{__('common.status')}}</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    {{__('common.action')}}</th>
                                                </tr>
                                        </tr>
                                    </thead>
                                    <tbody id="table">
                                       
                                        @if(!empty($PCCategory_list))
                                            @foreach($PCCategory_list as $key=>$category)
                                                <tr>
                                                    <td class="text-left ">{{$key+1}}</td>
                                                    <td class="text-left "> 
                                                        @if (!empty($category->categorydescription))
                                                        {{ $category->categorydescription[0]->categories_name }}
                                                        @endif
                                                    </td>
                                                    <td class="text-center">
                                                        <input type="number" class="col-xs-1 inputPassword2 width1" data-categories_id="{{$category->categories_id}}"  placeholder="" value="{{$category->sort_order}}" style="width:50px;">
                                                    </td>
                                                    <td class="text-center"> 
                                                        <div class="custom-control custom-switch">
                                                            <input type="checkbox" class="custom-control-input toggle-class" data-categories_id="{{$category->categories_id}}"   {{ $category->isavailabel=="Yes" ? 'checked' : '' }} data-id="{{$category->categories_id}}" id="customSwitch{{$category->categories_id}}">
                                                            <label class="custom-control-label" for="customSwitch{{$category->categories_id}}"></label>
                                                        </div>
                                                    </td>
                                                    <td class="align-items-center justify-content-center d-flex">
                                                        <a href="{{ route('pc-categories.show', $category->categories_id) }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-sm-inline mg-l-5"></span></a>
                                                        <a href="{{route('pc-products.show',$category->categories_id)}}" id="website_delete_btn" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="repeat"></i><span class="d-none d-sm-inline mg-l-5"></span></a>

                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table><!-- end table -->
                            </div>
                            <div class="row text-center px-2">
                                <!-- PAGINATION START -->
                                <div class="col-12 mt-4">
                                    <div class="d-md-flex align-items-center text-center justify-content-between">
                                        <span class="text-muted me-3">Showing {{$PCCategory_list->currentPage();}} - {{$PCCategory_list->lastItem();}} out of {{$PCCategory_list->total()}}</span>
                                        <ul class="pagination mb-0 justify-content-center mt-4 mt-sm-0">
                                            {{ $PCCategory_list->links() }}
                                        </ul>
                                    </div>
                                </div>
                                    <!-- PAGINATION END -->
                            </div><!--end row-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!--start delete modal-->
<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <h5>Are you sure want to delete ?</h5>
            <input type="hidden" id="delete_department_id" name="input_field_id">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
            <button type="submit" class="btn btn-primary delete_submit_btn">Yes</button>
        </div>
    </div>
</div>
</div>
<!--end delete modal-->

@push('scripts')

    
<script type="text/javascript">
  
  $('.toggle-class').change(function () {
      let status = $(this).prop('checked') === true ? 1 : 0;
      let categories_id = $(this).data('categories_id');
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
          type: "POST",
          dataType: "json",
          url: "{{ url('changeStatus') }}",
          data: { 'status': status, 'categories_id': categories_id },
          success: function (response) {
             Toaster(response.success);
          }
      });
  });
</script>

<script>
        $(document).ready(function() {

         // category sort order update
            $(".inputPassword2").on("blur",function(e){ 
                e.preventDefault();
                var categories_id = $(this).data('categories_id');
                var sort_order = $(this).val();
                console.log(categories_id);
                console.log(sort_order);
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type:"POST",
                    url: "{{route('pcCategrySortOrder')}}",
                    data:{categories_id:categories_id,sort_order:sort_order},
                    dataType:"json",
                    success:function(data){
                        Toaster(data.success);
                    }
                }); 
            }); 

        });
        
    </script>

@endpush
</x-app-layout>
