<?php

namespace Modules\Pcapi\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Auth;
use Modules\Pcapi\Models\PcCategoryDescription;
use Modules\Pcapi\Models\PcProduct;
use App\Models\Product;
use App\Models\ProductDescription;
use Modules\Pcapi\Models\PcCategory;
use Modules\Pcapi\Models\PcProductToCategory;


class PcProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public static function index(Request $request)
    {    
        
        $search = $request->search;
        if(!empty($search)){
            $PcProduct = PcProduct::with('productdescription');
            $data_query=$PcProduct->WhereHas('productdescription',function ($query)use($search)
            {
                $query->where("products_name","LIKE", "%{$search}%");
            });

            $product_list = $PcProduct->paginate(50);
        }
        else{
            $product_list = PcProduct::with('productdescription')->paginate(50);
        }
    
        return view('Pcapi::product.index',compact('product_list'));

    

     }

         /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($catId)
    {
        $product_list_query = PcProduct::with('productdescription','productTocategories');

        if(!empty($catId)){
            $data_query = $product_list_query->whereHas('productTocategories', function ($query) use($catId) { 
                $query->where('categories_id',$catId);  
            })->get();
        }
        $product_list =  $product_list_query->orderBy('sort_order', 'DESC')->paginate(50);

        $proTitle = PcCategory::where('categories_id',$catId)->first(['categories_name']);

        return view('Pcapi::product.index',compact('product_list','proTitle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
      //

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function changeStatus(Request $request)
    {
        $pcProduct = PcProduct::where('products_id' ,$request->products_id )->first();
        if(!empty($pcProduct))
        {
            // dd($pcProduct);
            $product =  Product::where('source_id',$pcProduct->products_id)->where('source', 2)->first();
            if(!empty($product))
            {
                $product->product_status = $request->status;
                $product->update();
                return response()->json(['status'=>1, 'success'=>' Product Status Changed Successfully']);

            }
            else{
                return response()->json(['status'=>1, 'success'=>' Please enable Category status first then change product status']);
            }

        }

    }
    public function sortOrder(Request $request)
    {
        $pcProduct = PcProduct::where('products_id' ,$request->products_id )->first();
        if(!empty($pcProduct))
        {
            $product =  Product::where('source_id',$pcProduct->products_id)->where('source', 2)->first();
            if(!empty($product))
            {
                $product->sort_order = $request->sort_order;
                $product->update();
                return response()->json(['status'=>1, 'success'=>' Product Status Changed Successfully']);
            }
            else 
            {
                return response()->json(['status'=>1, 'success'=>'Please enable Category status first then change product sort order']); 
            }  
         }

    }
  
 

}
