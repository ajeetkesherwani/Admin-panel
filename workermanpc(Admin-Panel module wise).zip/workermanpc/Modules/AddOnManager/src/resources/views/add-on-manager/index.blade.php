<style>
.pull-left button{
    float:right;
    margin: 1rem 0 0.6rem;
}
.btns{
    margin:0 10px!important;
}

.table_btn{
    margin:0 4px;
    }
</style>
<x-app-layout>
    <div class="container-fluid">
        <div class="layout-specing">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif
            <div class="d-md-flex justify-content-between align-items-center">
                <h5 class="mb-0">Add On Manager</h5>

                <!-- <nav aria-label="breadcrumb" class="d-inline-block">
                    <ul class="breadcrumb bg-transparent rounded mb-0 p-0">
                        <li class="breadcrumb-item text-capitalize"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item text-capitalize"><a href="#">Add On Manager</a></li>
                    </ul>
                </nav> -->
            </div>

            <div class="row">
               
                <div class="col-12 mt-4">
                    <div class="table-responsive">                     
                        <table class="table table-center bg-white mb-0">                       
                            <thead>
                                <tr>
                                    <th class="border-bottom p-3">#</th>
                                    <th class="border-bottom p-3" style="min-width: 220px;">Image</th>
                                    <th class="border-bottom p-3" style="min-width: 220px;">Add On Name</th>                                  
                                    <th class=" border-bottom p-3">Version</th>
                                    <th class="border-bottom p-3">Status</th>
                                    <th class="border-bottom p-3"">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Start -->
                                @if(!empty($add_on))
                                @foreach($add_on as $key => $data)
                                <tr>
                                    <td class="p-3">{{$key+1}}</td>
                                    <td class="p-3">{{$data->image}}</td>
                                    <td class="p-3">{{$data->addon_name}}</td>
                                    <td class="p-3">{{@$data->version}}</td>
                                     <!-- <td class="p-3"><i class="{{($data->status=='1') ? 'badge bg-primary' : 'badge bg-danger'}}"> {{($data->status=='1')?'Active':'Inactive'}}</i></td> -->

                                     <td class="p-3">
                                        <div class="form-check form-switch">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input toggle-class"   {{ $data->status ? 'checked' : '' }} data-id="{{$data->id}}" id="customSwitch{{$data->id}}">
                                                <label class="custom-control-label" for="customSwitch{{$data->id}}"></label>
                                            </div>

                                            
                                            {{-- <input data-id="{{$data->id}}"
                                            class="form-check-input toggle-class" type="checkbox"
                                            data-toggle="toggle" data-on="Active" data-off="InActive" {{ $data->status ? 'checked' : '' }}> --}}
                                        </div>
                                    </td>
                                    <td class="align-items-center justify-content-center d-flex"> 

                                        <a href="#papachina_edit" data-id="{{ $data->industry_id }}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-none d-sm-inline mg-l-5"></span></a>

                                        {{-- <a href="#" data-id="{{ $data->industry_id }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 edit_temp_btn" data-toggle="modal" data-bs-target="#papachina_edit"><i data-feather="eye"></i><span class="d-sm-inline mg-l-5"></span></a> --}}

                                        {{-- <button class=" btn-xs btn-icon table_btn edit_temp_btn" id="papachina_editmodal" data-id="{{ $data->industry_id }}" data-bs-toggle="modal" data-bs-target="#papachina_edit"><i class="uil uil-setting"></i></button> --}}
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                                <!-- End -->

                             </tbody> 
                        </table>
                    </div>
                </div><!--end col-->
            </div><!--end row-->

            <!-- <div class="row text-center">
                <!-- PAGINATION START -->
                <!-- <div class="col-12 mt-4">
                    <div class="d-md-flex align-items-center text-center justify-content-between">
                        <span class="text-muted me-3">Showing 1 - 10 out of 50</span>
                        <ul class="pagination mb-0 justify-content-center mt-4 mt-sm-0">
                            <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Previous">Prev</a></li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#" aria-label="Next">Next</a></li>
                            </ul>
                    </div> -->
                <!-- </div> -->
                <!-- PAGINATION END -->
            <!-- </div> --> 
            <!--end row-->
        </div>
    </div><!--end container-->   

        <!-- modal edit code start -->
        <div class="modal fade" id="papachina_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content tx-14">
                <form id="papachina_update_userForm" method="POST" class="needs-validation" novalidate>
                    @csrf
                    <div class="modal-header">
                        <h6 class="modal-title" id="exampleModalLabel">PapaChina Api Setting</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input name="industry_id" id="hidden_industry_id" type="hidden" class="form-control ps-5">
                                                
                        <div class=" row">
                            <label  class="col-sm-4 col-form-label">Profit Percent</label>
                            <div class=" form-icon col-sm-8">
                                <input type="text" readonly class="form-control" id="staticEmail" value="email@example.com">
                            </div>
                        </div>
                        <div class="row pt-2">
                            <label  class="col-sm-4 col-form-label">Enable Shipping</label>
                            <div class=" form-icon col-sm-8">
                                <input type="radio" id="contactChoice1" name="contact" value="email">
                                <label for="Choice1">Yes</label>
                                <input type="radio" id="contactChoice2" name="contact" value="phone">
                                <label for="Choice2">No</label>
                            </div>
                        </div>
                        <div class=" row">
                            <label  class="col-sm-4 col-form-label">Shipping Option </label>
                            <div class=" form-icon col-sm-8">
                                <select class="form-select form-control" name="access_privilege" id="update_access_privilege" required="">
                                    <option value="0">Ex</option>
                                    <option value="1">Ec</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-12">
                                <button type="submit" id="papachina_update_btn" class="btn btn-primary tx-13">Submit</button>
                            </div>
                        </div>
                        {{-- <div class="row">
                            <div class="col-sm-12" required>
                                <input type="submit" id="papachina_update_btn" name="send" class="btn-primary"">
                            </div><!--end col-->
                        </div>     --}}
                        <!--end row-->
                    </div>
                    
                </form>
              </div>
            </div>
          </div>


        

    @push('scripts')

    
      <script type="text/javascript">
        
        $('.toggle-class').change(function () {
            let status = $(this).prop('checked') === true ? 1 : 0;
            console.log(status);
            let id = $(this).data('id');
            console.log(id);

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{ url('changeStatus') }}",
             
                data: { 'status': status, 'id': id },
                success: function (response) {
                   // console.log(response);
                   Toaster(response.success);
                }
            });
        });
     </script>

      <script>
       
            // modal edit open ajax

            $(document).on("click", "#papachina_editmodal", function(e) {
                e.preventDefault();
                var addon_id = $(this).data('id');
                $('#papachina_edit').modal('show');
                $.ajax({
                    url: "add-on-manager/" + addon_id + "/edit",
                    type: "GET",
                    success: function(response) {
                        console.log(response);
                        if (response.status == 400) {
                            $('#errorlist').html("");
                            $('#errorlist').addClass("alert alert-danger");
                            $('#errorlist').append('<li>' + response.message + '</li>');

                        } else {
                            $('#edit_industry_name').val(response.industry.industry_name);
                            $('#hidden_industry_id').val(addon_id);
                        }
                    }
                });

            });
            // modal edit closed ajax


     
          
           
    </script>
    
    @endpush


</x-app-layout> 
