<?php
namespace Modules\AddOnManager\Http\Controllers;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Modules\AddOnManager\Models\AddOn;
use Modules\AddOnManager\Models\AddOnManager;
use Maatwebsite\Excel\HeadingRowImport;
use Maatwebsite\Excel\Imports\HeadingRowFormatter;
use App\Jobs\ImportWorkReportJob;
use Illuminate\Support\Facades\Bus;
use App\Helper\Reply;
use Artisan;
use Carbon\Carbon;
use Session;
use DB;
use App\Http\Requests\FileRequest\ImportProcessRequest;
// use app\Http\Requests\FileRequest\ImportRequest;
use Maatwebsite\Excel\Facades\Excel;




class AddOnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $add_on=AddOn::get();
       // dd( $add_on);
        return view('AddOnManager::add-on-manager.index',compact('add_on'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
        $industry = AddOn::find($id);
      
        return response()->json(['industry'=>$industry]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function changeStatus(Request $request)
    {
       //  dd($request->all());
        $addOn =  AddOn::where('id' ,$request->id)->first();
        $addOn->status = $request->status;
        $addOn->update();

                    
           if(!empty($addOn)){

          AddOnManager::updateOrCreate(['addon_id'   => $addOn->id],
            [
            'status'=>$addOn->status,
     
            ]
           );
      

           }
          

        return response()->json(['status'=>1, 'success'=>' Add On  Status Changed Successfully']);
    }




}
