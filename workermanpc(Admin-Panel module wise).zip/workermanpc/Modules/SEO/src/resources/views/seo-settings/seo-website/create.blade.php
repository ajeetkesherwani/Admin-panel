<x-app-layout>
    <div class="container-fluid">
        <div class="layout-specing">
            <div class="col-md-12">
                <form action="{{route('seo-website.store')}}" id="userForm" method="POST" class="needs-validation" novalidate>
                    <div class="card-header bg-transparent px-4 py-3">
                        <h5 class="text-md-start text-center  d-inline">{{ __('seo.seo_website_form') }} </h5>
                    </div>

                    <div data-label="Example" class="df-example demo-forms">
                        <div class="form-row mt-4 mx-4">
                            <div class="form-group col-md-6">
                                <label class="form-label">{{ __('seo.website_name') }}  <span class="text-danger">*</span></label>
                                <div class="form-icon position-relative">
                                    <input name="website_name" value="{{old('website_name')}}"  id="seo_task_title"  type="text" class="form-control @error('website_name') is-invalid @enderror" placeholder="{{ __('seo.website_name_placeholder') }}" required>
                                    <div class="invalid-feedback">
                                        <p>{{ __('seo.website_name_error') }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label">{{ __('seo.website_url') }}  <span class="text-danger">*</span></label>
                                <div class="form-icon position-relative">
                                    <input name="website_url" value="{{old('website_url')}}"  id="seo_task_title"  type="text" class="form-control @error('website_url') is-invalid @enderror" placeholder="{{ __('seo.website_url_placeholder') }}" required>
                                    <div class="invalid-feedback">
                                        <p>{{ __('seo.website_url_error') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-row mx-4">

                            <div class="form-group col-md-6">
                                <label class="form-label">{{ __('seo.start_date') }} <span class="text-danger">*</span></label>
                                <input name="start_Date" value="{{old('start_Date')}}"  id="datepicker1"  type="" class="form-control @error('start_Date') is-invalid @enderror" placeholder="{{ __('seo.start_date_placeholder') }}" required>
                                <div class="invalid-feedback">
                                    <p>{{ __('seo.start_date_error') }}</p>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="form-label">{{ __('seo.country') }} </label>
                                <select name="countries_id" class="form-select form-control @error('countries_id') is-invalid @enderror" name="country" aria-label="Default select example" >
                                    <option selected disabled value="">{{ __('seo.select_country') }} </option>
                                    @foreach($country_list as $country)
                                    <option value="{{$country->countries_id}}" >{{$country->countries_name}}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback">
                                    <p>{{ __('seo.website_country_error') }}</p>
                                </div>
                            </div>

                        </div>
                        
                    </div><!--end row-->
                    <div class="row">
                        <div class="col-sm-12 mb-4 mx-4">
                            <input type="submit" id="submit" name="send" class="btn btn-primary" value="Submit">
                            <a href="{{ route('workReport') }}" class="btn btn-light mx-1 "> <i class="fas fa-backward" aria-hidden="true"></i>{{ __('common.goback') }} </a>
                        </div><!--end col-->
                    </div><!--end row-->
                </form>
            </div>
        </div>
    </div>


    @push('scripts')
    {{-- <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css"> --}}
        <script>
        $( function() {
            $('#datepicker1').datepicker();
        } );
        
            // $('#submit').on("click", function(e){
            //     e.preventDefault();
            //     $('#userForm').addClass('was-validated');
            //     if ($('#userForm')[0].checkValidity() === false) {
            //         event.stopPropagation();
            //     } 
            //     else{
            //         console.log('submit');
            //         $("#userForm").submit();
            //     }
            // });
        </script>        
 
    @endpush
</x-app-layout>