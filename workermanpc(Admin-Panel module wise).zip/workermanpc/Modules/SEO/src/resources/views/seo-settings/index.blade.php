<x-app-layout>
    <div class="contact-content">
        <div class="contact-content-header">
            <ul class="nav nav-line" id="myTab" role="tablist">
                <li class="nav-item"> <a href="#website" class="nav-link active" data-toggle="tab">{{ __('seo.website') }}</a></li>
                <li class="nav-item"> <a href="#task" class="nav-link" data-toggle="tab">{{ __('seo.task_setting') }}</a></li>
                <li class="nav-item"><a href="#result" class="nav-link" data-toggle="tab">{{ __('seo.result_title') }}</a></li>
            </ul>
            <a href="" id="contactOptions" class="text-secondary mg-l-auto d-xl-none"><i data-feather="more-horizontal"></i></a>
        </div><!-- contact-content-header -->
        <div class="contact-content-body">
            <div class="tab-content">
                <div id="website" class="tab-pane show active pd-20 pd-xl-25">
                    <div class="d-flex align-items-center justify-content-between mg-b-30">
                        <h6 class="tx-15 mg-b-0">{{ __('seo.website_list') }}</h6>
                        <a href="{{ route('seo-website.create') }}"  class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5">{{__('seo.add_website')}}</span></a>
                    </div>
                    <div data-label="Example" class="df-example demo-table">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th class="wd-10p">{{ __('common.sl_no') }}</th>
                                    <th class="wd-20p">{{__('seo.website_name') }}</th>
                                    <th class="wd-25p">{{__('seo.website_url') }}</th>
                                    <th class="wd-15p">{{ __('seo.start_date') }}</th>
                                    <th class="wd-15p">{{ __('common.status') }}</th>
                                    <th class="wd-10p">{{ __('common.action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($web_setting))
                                @foreach ($web_setting as $key => $web)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $web->website_name }}</td>
                                    <td>{{ $web->website_url }}</td>
                                    <td>{{ $web->start_date }}</td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input website_toggle_class" {{ $web->status == '1' ? 'checked' : '' }} data-id="{{$web->id}}" id="customSwitch{{$web->id}}">
                                            <label class="custom-control-label" for="customSwitch{{$web->id}}"></label>
                                          </div>
                                          
                                    </td> 
                                    <td class="d-flex align-items-center">

                                    <a href="{{ url('seo-website/' . $web->id . '/edit') }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i><span class="d-sm-inline mg-l-5"></span></a>
                                    <a href="#delete_modal" id="website_delete_btn" data-toggle="modal" data-id="{{$web->id}}" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="trash"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div><!-- df-example -->
                </div>
                <div id="task" class="tab-pane pd-20 pd-xl-25">
                    <div class="d-flex align-items-center justify-content-between mg-b-30">
                        <h6 class="tx-15 mg-b-0">{{ __('seo.task_list') }}</h6>
                        <a href="{{ route('seo-task.create') }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5">{{ __('seo.add_task') }}</span></a>
                    </div>
                    <div data-label="Example" class="df-example demo-table">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th class="wd-10p">{{__('common.sl_no') }}</th>
                                    <th class="wd-10p">{{__('seo.task_priority') }}</th>
                                    <th class="wd-20p">{{__('seo.task_title') }}</th>
                                    <th class="wd-10p">{{__('seo.no_of_submission') }}</th>
                                    <th class="wd-20p">{{__('seo.task_frequency') }}</th>
                                    <th class="wd-10p">{{__('common.status') }}</th>
                                    <th class="wd-10p">{{ __('common.action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($seotask))
                                @foreach ($seotask as $key => $task)
                                <tr>
                                    <td>{{ ++$key }}</td>
                                    <td>{{ ucwords($task->task_priority) }}</td>
                                    <td>{{ ucwords($task->seo_task_title) }}</td>
                                    <td>{{ ucwords($task->no_of_submission) }}</td>
                                    <td>
                                        @if (!empty($task->task_frequency == 1))
                                        Daily
                                        @elseif(!empty($task->task_frequency == 2))
                                        Weekly Once
                                        @elseif(!empty($task->task_frequency == 3))
                                        Weekly Twice
                                        @elseif(!empty($task->task_frequency == 4))
                                        Weekly Thrice
                                        @endif
                                    </td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input task_toggle_class" {{ $task->status == '1' ? 'checked' : '' }} data-id="{{$task->id}}" id="customSwitch{{$task->id}}">
                                            <label class="custom-control-label" for="customSwitch{{$task->id}}"></label>
                                        </div>
                                        
                                    </td>
                                    <td class="d-flex align-items-center">
                                    <a href="{{ url('seo-task/' . $task->id . '/edit') }}"
                                    data-task-id="{{ $task->id }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    <a href="#task_delete" id="task_del_btn" data-id="{{ $task->id }}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="trash"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div><!-- df-example -->
                </div><!-- tab-pane -->
                <div id="result" class="tab-pane pd-20 pd-xl-25">
                    <div class="d-flex align-items-center justify-content-between mg-b-30">
                        <h6 class="tx-15 mg-b-0">{{ __('seo.result_list') }}</h6>
                        <a href="#modal1" data-toggle="modal" id="add_title_btn" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5">{{ __('seo.add_result_title') }}</span></a>
                    </div>
                    <div data-label="Example" class="df-example demo-table">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th class="wd-20p">{{ __('seo.title') }}</th>
                                    <th class="wd-25p">{{ __('seo.sub_title') }}</th>
                                    <th class="wd-20p">{{ __('common.status') }}</th>
                                    <th class="wd-10p">{{ __('common.action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($seoresult))
                                @foreach ($seoresult as $key => $result)
                                <tr>
                                    <td>{{ ucwords($result->title_name) }}</td>
                                    <td></td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input result_toggle_class" {{ $result->status == '1' ? 'checked' : '' }} data-id="{{$result->id}}" id="customSwitch{{$result->id}}">
                                            <label class="custom-control-label" for="customSwitch{{$result->id}}"></label>
                                        </div>
                                    </td>
                                    <td class="d-flex align-items-center">
                                        <a href="#modalEditResult" data-id="{{$result->id}}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 result_edit_btn"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    <a href="#delete_result_modal" data-id="{{$result->id}}" id="result_delete_btn" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="trash"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                                @foreach ($result->child as $key => $child)
                                <tr>
                                    <td></td>
                                    <td>{{ ucwords($child->title_name) }}</td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input result_toggle_class" {{ $child->status == '1' ? 'checked' : '' }} data-id="{{$child->id}}" id="customSwitch{{$child->id}}">
                                            <label class="custom-control-label" for="customSwitch{{$child->id}}"></label>
                                        </div>
                                    </td>
                                    <td class="d-flex align-items-center">
                                    <a href="#modalEditResult" data-id="{{$child->id}}" data-toggle="modal"  class="btn btn-sm btn-white d-flex align-items-center mg-r-5 result_edit_btn"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    <a href="#delete_result_modal" data-id="{{$child->id}}" id="child_delete" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center "><i data-feather="trash"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                                @endforeach
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div><!-- df-example -->
                </div>
            </div><!-- tab-content -->
        </div><!-- contact-content-body -->

    </div><!-- contact-content -->

    <!--Website delete modal-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h6 class="modal-title">{{ __('seo.delete_task') }}</h6>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               <input type="hidden" id="hidden_id" name="input_field_id">
              <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                {{ __('common.no')}}
                </button>
                <button type="button" class="btn btn-primary delete_btn">{{ __('common.yes') }}</button>
            </div>
          </div>
        </div>
    </div>
    <!--End delete modal-->

    <!--task delete modal-->
    <div class="modal fade effect-scale" id="task_delete" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h6 class="modal-title">{{ __('seo.delete_task') }}</h6>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <input type="hidden" id="delete_task_id" name="input_field_id">
            <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('common.no')
                        }}</button>
            <button type="button" class="btn btn-primary task_delete_yes">{{ __('common.yes') }}</button>
          </div>
        </div>
      </div>
    </div>
    <!--end delete modal-->

     <!--result delete modal-->
    <div class="modal fade effect-scale" id="delete_result_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h6 class="modal-title">{{ __('seo.delete_task') }}</h6>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               <input type="hidden" id="result_hidden_id" name="input_field_id">
              <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                {{ __('common.no')}}
                </button>
                <button type="button" class="btn btn-primary delete_btn">{{ __('common.yes') }}</button>
            </div>
          </div>
        </div>
    </div>
    <!--End delete modal-->
   
    <!--------------Add Result Modal --------------->
    <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('seo.title') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="add_result_title_form" novalidate>

                        <div class="row">
                            <div class="col-sm-12">
                                <label class="form-label">{{ __('seo.title') }}<span
                                        class="text-danger">*</span></label>
                                <div class="form-icon position-relative">
                                    <input name="title" id="title" type="text" class="form-control"
                                        placeholder="Enter title" required>
                                    <span style="color:red;">
                                        @error('title')
                                        {{$message}}
                                        @enderror
                                    </span>
                                    <div class="invalid-feedback">
                                        <p>{{ __('seo.task_title_error') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 mt-4">
                                
                                <label for="section_type" class="form-label">{{ __('seo.section_type')
                                    }}</label><br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input section_type is-invalid" type="radio"
                                        name="section_type" id="section_type" value="0" checked>
                                    <label class="form-check-label" for="inlineRadio1">{{ __('seo.parent')
                                        }}</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input section_type1 is-invalid" type="radio"
                                        name="section_type" id="section_type1" value="1">
                                    <label class="form-check-label" for="inlineRadio2">{{ __('seo.child')
                                        }}</label>
                                </div>
                                <div class=" parent mt-3" style="display:none;">
                                    <label for="parent_section" class="form-label">{{ __('seo.parent_title')
                                        }}</label>
                                    <select class="form-control" id="parent_section" name="parent_section" >
                                        <option selected disabled value="">{{ __('seo.select_parent_title') }}
                                        </option>

                                    </select>
                                    <div class="invalid-feedback">
                                        Please select parent title
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!-------------- Add Result Modal end here --------------->


     <!-------------- Edit Result Modal --------------->
    <div class="modal fade" id="modalEditResult" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('seo.update_title') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="edit_result_title_form" novalidate>
                        <input type="hidden" name="input_field_id" id="edit_input_field">
                        <div class="row">
                            <div class="col-sm-12">
                                <label class="form-label">{{ __('seo.title') }}<span
                                        class="text-danger">*</span></label>
                                <div class="form-icon position-relative">
                                     <input name="title" id="update_title" type="text" class="form-control" placeholder="Enter title" required>
                                    <span style="color:red;">
                                        @error('title')
                                        {{$message}}
                                        @enderror
                                    </span>
                                    <div class="invalid-feedback">
                                        <p>{{ __('seo.task_title_error') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 mt-4">
                                
                                <label for="section_type" class="form-label">{{ __('seo.section_type')
                                    }}</label><br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input  section_type is-invalid type"
                                                type="radio" name="section_type" id="update_section_type" value="0">
                                    <label class="form-check-label" for="inlineRadio1">{{ __('seo.parent')
                                        }}</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input  section_type1 is-invalid type" type="radio" name="section_type" id="update_section_type1" value="1">
                                    <label class="form-check-label" for="inlineRadio2">{{ __('seo.child')
                                        }}</label>
                                </div>
                                <div class=" parent mt-3" style="display:none;">
                                    <label for="parent_section" class="form-label">{{ __('seo.parent_title')
                                        }}</label>
                                    <select class="form-control " id="update_parent_section" name="parent_section" >
                                            <option selected disabled value="">{{ __('seo.select_parent_title') }}
                                            </option>
                                            
                                        </select>
                                    <div class="invalid-feedback">
                                        Please select parent title
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!--------------Edit Result Modal end here --------------->
        
    @push('scripts')
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function(){
          $(".section_type").click(function(){
            $(".parent").hide();
          });
          $(".section_type1").click(function(){
            $(".parent").show();
          });
        });
    </script>

    <!-- DROPDOWN-->
    <script>
        $(document).ready(function() {
            $('#add_title_btn').click( function(){
                // alert('drop');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });
                $.ajax({
                    url:"{{ route('dropdown') }}",
                    type: "POST",
                    success: function(result) 
                    {
                        console.log(result);
                        $.each( result.seoresult, function( key, value ) {
                            // console.log(value.title_name);
                              let option_html = "<option value='"+value.id+"'>"+ value.title_name +"</option>"
                                $("#parent_section").append(option_html);
                            });
                    }
                });
            });
        });
    </script>
    <!--END DROPDOWN-->

    <!--add result title ajax-->
    <script>
        
        $(document).on("submit","#add_result_title_form",function(e){
            e.preventDefault();
           
            let section_type = $("#section_type:checked").val();
            var formData = {
            title: $("#title").val(),
            parent_section_id : $("#parent_section").val()??0,
            status: $("#status").val(),
            };
            
            $.ajaxSetup({
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
               url:"{{route('seo-results-data.store')}}",
               type:"POST",
               data: formData,
               dataType: "json",
               success: function(response){
                
                console.log(response);
                $('#modal1').removeClass('show');
                $('#modal1').css('display','none');
               
                    Toaster(response.success);
                    setTimeout(function() {
                        location.reload(true);
                    }, 3000);
                    
               },

            });
        });
    </script>
    <!--end add result title ajax-->

    <script>
        //modal edit title ajax
        $(document).ready(function() {
            
            $('.result_edit_btn').on('click',function (e) {
                e.preventDefault();
                var result_id =  $(this).data('id');
               
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "GET",
                    url: "{{url('seo-results-data')}}/"+result_id+"/edit",
                    data: {result_id:result_id},
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        var sec = response.section;
                        // var mod = response.result;
                            $("#edit_input_field").val(sec.id);
                            $("#update_title").val(sec.title_name);
                            if(sec.parent_id == 0){
                                $('#update_section_type').prop('checked', 'true');
                            }
                            else{
                                $('#update_section_type1').prop('checked', 'true');
                                
                            }
                            console.log(sec.parent_id);
                            if(sec.parent_id != '0'){
                               
                                $("#update_title").val(sec.title_name);
                                $("#update_parent_section").html('');

                            // console.log(response.result);
                                $.each(response.result, function( key, value ) {
                                    // console.log(value);
                                  let option_html = "<option value='"+value.id+"'>"+ value.title_name +"</option>";
                                    $("#update_parent_section").append(option_html);
                                    $("#update_parent_section").val(sec.parent_id);
                                    $('.parent').show();
                                });
                            
                            }
                            else{
                               
                                $('.parent').hide();

                            }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            });
        });
       
    //   Edit title closed ajax
    </script>

    <!--update result title jquery-->
    <script>
        $(document).ready(function(){
           
            $(document).on("submit", "#edit_result_title_form",function(e){
                e.preventDefault();
               
                var data = {
                     id: $("#edit_input_field").val(),
                     title: $("#update_title").val(),
                     parent_id: $("#update_parent_section").val(),
                     section_type: $('.type').prop('checked') === true ? 0 : 1,
                    
                }
                
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{route('seo-results-update')}}",
                    data: data,
                    success: function (response) {
                        $('#modalEditResult').removeClass('show');
                        $('#modalEditResult').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 3000);
                       
                       
                    }
                });
               
            });
        });
    </script>
    <!--end result title update jquery-->

    <!--task delete ajax -->
    <script>
        $(document).ready(function() {
            $(document).on("click", "#task_del_btn", function() {
                var task_id = $(this).data('id');
                
                $('#delete_task_id').val(task_id);
                // $('#delete_modal1').modal('show');
            });
            $(document).on('click', '.task_delete_yes', function() {
                var task_id = $('#delete_task_id').val();

                // $('#task_delete').modal('hide');
                // alert(task_id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('seo-task') }}/" + task_id,
                    data: {
                        task_id: task_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        $('#task_delete').removeClass('show');
                        $('#task_delete').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                        location.reload(true);
                    }, 3000);

                    }
                });

            });

            //website delete jquery start here
            $(document).on("click", "#website_delete_btn", function() {
                var seo_id = $(this).data('id');
                $('#hidden_id').val(seo_id);
            });
            $(document).on('click', '.delete_btn', function() {
                var seo_id = $('#hidden_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('seo-website') }}/" + seo_id,
                    data: {
                        seo_id: seo_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        $('#delete_modal').removeClass('show');
                        $('#delete_modal').css('display','none');
                        Toaster(response.success);
                        $("#website_table").load(location.href + " #website_table");
                        $("#website_table1").load(location.href + " #website_table1");
                        $('#delete_modal').fadeOut(6000, function() {
                            location.reload(true);
                        });
                    }
                });
            });

            //website status change jquery
            $('.website_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let website_id = $(this).data('id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{route('changeWebsiteStatus')}}",
                    data: { 'status': status, 'website_id': website_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    }
                });
            });

            //task status change jquery
            $('.task_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let task_id = $(this).data('id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{route('changeTaskStatus')}}",
                    data: { 'status': status, 'task_id': task_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    }
                });
            });

            //result parent title status change jquery
            $('.result_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let result_id = $(this).data('id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{route('changeResultStatus')}}",
                    data: { 'status': status, 'result_id': result_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    
                    }
                });
            });

            //result parent delete jquery start here
            $(document).on("click", "#result_delete_btn", function() {
                var result_id = $(this).data('id');
                
                $('#result_hidden_id').val(result_id);
            });
            $(document).on('click', '.delete_btn', function() {
                var result_id = $('#result_hidden_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('seo-results-data') }}/" + result_id,
                    data: {
                        result_id: result_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        $('#delete_result_modal').removeClass('show');
                        $('#delete_result_modal').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                        location.reload(true);
                    }, 3000);

                       
                    }
                });
            });

            //result child delete jquery start here
            $(document).on("click", "#child_delete", function() {
                var delete_child = $(this).data('id');
                
                $('#result_hidden_id').val(delete_child);
            });
            $(document).on('click', '.delete_btn', function() {
                var delete_child = $('#result_hidden_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('child-delete') }}/" + delete_child,
                    data: {
                        delete_child: delete_child,
                       
                    },
                    dataType: "json",
                    success: function(response) {
                        $('#delete_result_modal').removeClass('show');
                        $('#delete_result_modal').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                        location.reload(true);
                    }, 3000);

                       
                    }
                });
            });

        });
    </script>
    <!--end task delete ajax-->

    

 @endpush
</x-app-layout>