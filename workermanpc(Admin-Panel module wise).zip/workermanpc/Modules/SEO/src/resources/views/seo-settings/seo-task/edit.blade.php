<x-app-layout>
<div class="container-fluid">
    <div class="layout-specing ">
        <div class="col-md-12 ">
            <div class="">
            <form action="{{route('seo-task.update',$seotask->id)}}" id="userForm" method="POST" data-toggle="validator">
                @csrf
                 {{method_field('PUT')}}
                <div class="card-header bg-transparent px-4 py-3">
                    <h5 class="text-md-start text-center  d-inline">{{ __('seo.update_task_title') }}</h5>
                </div>

                <div data-label="Example" class="df-example demo-forms mt-4">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-label">{{ __('seo.task_title')}}<span class="text-danger">*</span></label>
                            <div class="form-icon position-relative">
                               
                                <input name="seo_task_title" data-error="{{__('seo.task_title_error')}}" id="seo_task_title" value="{{$seotask->seo_task_title}}"  type="text" class="form-control " placeholder="{{ __('seo.task_title_placeholder') }}" required>
                                <div class="invalid-feedback">
                                    <p>{{ __('seo.task_title_error') }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label">{{ __('seo.task_priority') }}<span class="text-danger">*</span></label>
                            <select class="form-select form-control" data-error="{{ __('seo.task_priority_error')}}" name="task_priority" value="{{$seotask->task_priority}}" aria-label="Default select example" required>
                                <option selected disabled value="">{{ __('seo.select_task_priority') }}</option>
                                @for($priority = 1; $priority <= 20; $priority++)
                                @php
                                $selected = '';
                                if($priority == $seotask->task_priority){
                                    $selected = 'selected';
                                }
                                @endphp
                                <option value="{{$priority}}" {{$selected}}>{{$priority}}</option>
                                @endfor
                            </select>
                            <div class="invalid-feedback">
                                <p>{{ __('seo.select_task_priority') }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="form-label">{{ __('seo.task_frequency') }} <span class="text-danger">*</span></label>
                            <select class="form-select form-control" data-error="{{ __('seo.task_frequency_error') }}"  name="task_frequency" aria-label="Default select example" required>
                                
                                <option  selected disabled value="">{{ __('seo.select_task_frequency') }}</option>
                                <option value="1" {{ $seotask->task_frequency == '1' ? 'selected' : '' }}>Daily</option>
                                <option value="2" {{ $seotask->task_frequency == '2' ? 'selected' : '' }}>Weekly Once</option>
                                <option value="3" {{ $seotask->task_frequency == '3' ? 'selected' : '' }}>Weekly Twice</option>
                                <option value="4" {{ $seotask->task_frequency == '4' ? 'selected' : '' }}>Weekly Thrice</option>
                            </select>
                            <div class="invalid-feedback">
                                <p>{{ __('seo.select_task_frequency') }}</p>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label">{{ __('seo.no_of_submission') }} </label>
                                <select class="form-select form-control" name="no_of_submission" aria-label="Default select example" >
                                 <option selected disabled value="">{{ __('seo.select_no_of_submission') }}</option>
                                @for($sub = 1; $sub <= 100; $sub++)
                                @php
                                $selected = '';
                                if($sub == $seotask->no_of_submission){
                                    $selected = 'selected';
                                }
                                @endphp
                                <option value="{{ $sub}}" {{$selected}}>{{$sub}}</option>
                                @endfor
                                    </select>
                        </div>
                    </div>
                </div><!--end row-->
                <div class="row">
                    <div class="col-sm-12">
                        <input type="submit" id="submit" name="send" class="btn btn-primary" value="Update">
                        <a href="{{ route('workReport') }}" class="btn btn-light mx-1 "> <i class="fas fa-backward" aria-hidden="true"></i>{{ __('common.goback') }}  </a>
                    </div><!--end col-->
                </div><!--end row-->
            </form>
            </div>
        </div>
    </div>
</div>


    @push('scripts')
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
        <script>
        $( function() {
            $( "#datepicker" ).datepicker();
        } );
        </script>
    @endpush
</x-app-layout>