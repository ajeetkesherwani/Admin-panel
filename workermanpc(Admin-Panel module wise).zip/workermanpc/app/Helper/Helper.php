<?php
namespace App\Helper;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session; 
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\Industry;
use App\Models\UserBusiness;
use App\Models\Subscription;
use Modules\AddOnManager\Models\AddOn;

use Auth;

class Helper
{
	public static function role_slug(){

		$role_slug =  !empty(Auth()->user()->role->roles) ? Auth()->user()->role->roles->roles_key : '';
		return $role_slug;

	}



	public static function essential_config_regenerate($db_id='')
    {

        $sub_prefix = env('DB_SUBSCRIBER_PREFIX', 'lab_subs_');
        $dbsuperadmin = env('DB_SUPERADMIN', 'lab_superadmin');
        $db_id = Session::get('db_id');
       
		if (isset($db_id) && $db_id > 0) {

            //SUBSCRIBER DATABASE
            $db_name = $sub_prefix . $db_id;

            //USER RELATED TABLE
            $users_table = $db_name . '.usr_users';
            $roles_table = $db_name . '.usr_roles';
            //$permissions_table = $db_name . '.usr_permissions';
            //$permissions_table = $db_name . '.app_permissions';

            $user_has_roles_table = $db_name . '.usr_user_has_roles';
            $role_has_permissions_table = $db_name . '.usr_role_has_permissions';
            $user_logins_table = $db_name . '.usr_user_logins';


            config(['dbtable.common_users' => $users_table]);
            config(['dbtable.common_roles' => $roles_table]);
            config(['dbtable.common_user_has_roles' => $user_has_roles_table]);
            config(['dbtable.common_role_has_permissions' => $role_has_permissions_table]);
            config(['dbtable.common_user_logins' => $user_logins_table]);

		}

        $sub_subscription_to_user_table = $dbsuperadmin . '.sub_subscription_to_user';

        config(['dbtable.common_sub_subscription_to_user_table' => $sub_subscription_to_user_table]);
		
	}


    

    public static function DBConnect()
    {
        $database_suffix =  session()->get('db_id');
        
        //dd( $database_suffix );
        
        if($database_suffix){
            $sub_prefix = env('DB_SUBSCRIBER_PREFIX', 'lab_subs_');
            $currentDatabase = $sub_prefix.$database_suffix;

            $tenantPath = storage_path('framework/cache/data/'.$database_suffix);
            // Erase the tenant connection, thus making Laravel get the default values all over again.
            DB::purge('mysql');
            // Make sure to use the database name we want to establish a connection.

            Config::set('cache.prefix', $database_suffix);
            Config::set('database.connections.mysql.database', $currentDatabase);
            config(['cache.stores.file.path'=>$tenantPath]);
            Cache::forgetDriver();

            // Rearrange the connection data
            DB::reconnect('mysql');
            // Ping the database. This will throw an exception in case the database does not exists.
            Schema::connection('mysql')->getConnection()->reconnect();
        }

        //update_mail_config();

        $current_indutry_id = self::get_industry_id();
        $enable_module = '';
        if($current_indutry_id ==1){
            $enable_module = array('CRM', 'Setting', 'Newsletter', 'Usermanage','AddOnManager', 'Pcapi');
        }else if($current_indutry_id ==2){
            $enable_module = array('CRM', 'Setting', 'Newsletter', 'Usermanage');
        } else if($current_indutry_id ==3){
            $enable_module = array('SEO', 'AddOnManager', 'Newsletter', 'Usermanage');
        }
        Config::set('module.enable', $enable_module);
    }



    public static function get_industry_id( $subscription_id='')
    {
        $subscription_id =  session()->get('subs_id');

       // $userEmail = $request->email;
        $business = UserBusiness::where('subscription_id', $subscription_id)->first();
        if ($business !== null) {
            return !empty($business->subscription) ? $business->subscription->industry_id : 0;
        } else {
            return 0;
        }

    }
    
    // add on activation check
        
    public static function addon_is_activated($identifier, $default = null)
    {
        // $addons = Cache::remember('addons', 86400, function () {
        //     return Addon::all();
        // });

        $activation = Addon::where('unique_identifier', $identifier)->where('activated', 1)->first();
        return $activation == null ? false : true;
    }
    
    

}