<?php

namespace App\Models;

use App\Models\Scopes\StatusScope;
use App\Models\Ecom\Scopes\SortOrderScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Ecom\Product;
use App\Models\Ecom\Brand;
use App\Models\Ecom\Services\CategoryService;

class ProductToCategory extends Model
{
    use HasFactory;
    protected $connection= 'mysql';
    protected $table = 'ecm_products_to_categories';
    protected $fillable = [
        'products_id',
        'categories_id',
    ];
    public $timestamps = false;

}
