<div class="content-search">
    <i data-feather="search"></i>
    <input type="search" class="form-control" placeholder="Search...">
</div>
<nav class="nav">
    <!-- <a href="" class="nav-link"><i data-feather="help-circle"></i></a>
    <a href="" class="nav-link"><i data-feather="grid"></i></a>
    <a href="" class="nav-link"><i data-feather="align-left"></i></a>
    <div class="dropdown dropdown-primary">
        <button type="button" class="btn btn-soft-light dropdown-toggle p-0" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false"><i class="uil uil-user-circle fs-4 mb-0 px-1"></i></button>
        <div class="dropdown-menu dd-menu dropdown-menu-end shadow border-0 mt-3 py-3" style="min-width: 200px;">
            <a class="dropdown-item d-flex align-items-center text-dark pb-3">
                <i class="uil uil-user-circle fs-4 mb-0"></i>
                <div class="flex-1 ms-2">
                    <span class="d-block">{{auth()->user()->name}}</span>
                    {{-- <small class="text-muted">UI / UX Designer</small> --}}
                </div>
            </a>
            <a class="dropdown-item text-dark" href="{{route('dashboard')}}"><span class="mb-0 d-inline-block me-1"><i
                        class="ti ti-home"></i></span> Dashboard</a>
            <a class="dropdown-item text-dark" href="{{route('my-profile')}}"><span class="mb-0 d-inline-block me-1"><i
                        class="ti ti-settings"></i></span> Profile</a>
            <div class="dropdown-divider border-top"></div>

            <form method="POST" action="{{ route('logout') }}">
                @csrf

                <button type="submit" class="dropdown-item text-dark">
                    <span class="mb-0 d-inline-block me-1"><i class="ti ti-logout"></i></span>{{ __('Log Out') }}
                </button>
            </form>
        </div>
    </div> -->
    <div class="d-flex align-items-center nav-right gap-4">
        <div class="dropdown dropdown-notification mt-2"><a href="/" class="dropdown-link new-indicator"
                data-toggle="dropdown"><svg width="24" height="24" viewBox="0 0 24 24" fill="white" stroke="currentColor"
                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell ">
                    <g>
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                        <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                    </g>
                </svg><span>12</span></a>
            <div class="dropdown-menu dropdown-menu-right dropdown-notification-sub">
                <div class="dropdown-header d-flex align-items-center justify-content-between">Notifications<p
                        class="tx-right mb-0"> Clear All</p>
                </div>
                <a class="dropdown-item" href="/">
                    <div class="media">
                        <div class="avatar avatar-sm avatar-online"><img src="https://via.placeholder.com/350"
                                class="rounded-circle" alt=""></div>
                        <div class="media-body mg-l-15">
                            <p>Login Activity<br><strong>User Login from. Current ip : 122.160.115.240</strong>
                                <br><span><time datetime="1674082860000">Thu Jan 19 2023 04:31:00 GMT+0530</time></span></p>
                        </div>
                    </div>
                </a>

                <div class="dropdown-footer"><a href="/">View All Notifications</a></div>
            </div>
        </div>
        <div class="dropdown dropdown-profile">
            <a href="/" class="dropdown-link" data-toggle="dropdown" data-display="static">
                <div class="avatar avatar-sm">
                    <img src="https://e-nnovation.net/backend/public/storage/images/profile_avatar.png"
                        class="rounded-circle" alt="">
                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-profile-sub tx-13">
                <div class="avatar avatar-lg mg-b-15">
                    <img src="https://e-nnovation.net/backend/public/storage/images/profile_avatar.png"
                        class="rounded-circle" alt="">
                </div>
                <h6 class="tx-semibold mg-b-5">Dev 01</h6><a class="dropdown-item" href="/user/edit/1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="white" stroke="currentColor" stroke-width="2"
                        stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-3 ">
                        <g>
                            <path d="M12 20h9"></path>
                            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                        </g>
                    </svg>Edit Profile</a><a class="dropdown-item" href="/account-setting"><svg width="24" height="24"
                        viewBox="0 0 24 24" fill="white" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="feather feather-edit-3 ">
                        <g>
                            <path d="M12 20h9"></path>
                            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                        </g>
                    </svg>Account Setting</a>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf

                        <button type="submit" class="dropdown-item text-dark">
                            <span class="mb-0 d-inline-block me-1"><i class="ti ti-logout"></i></span>{{ __('Log Out') }}
                        </button>
                    </form>
            </div>
        </div>
    </div>
</nav>