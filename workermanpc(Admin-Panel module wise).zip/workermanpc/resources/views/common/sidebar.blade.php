
@php
$indexurl =  Request::segment(1);
$role = App\Helper\Helper::role_slug();

$enabled_module = Config::get('module.enable', 'Test');

@endphp


<div class="aside-header">
    <a href="/" class="aside-logo"><img src="{{asset('assets/images/workerman.png')}}" height="32px" class="logo-light-mode" alt="Logo"></a>
    <a href="" class="aside-menu-link">
        <i data-feather="menu"></i>
        <i data-feather="x"></i>
    </a>
</div>

<div class="aside-body">
    <div class="aside-loggedin">
      <div class="d-flex align-items-center justify-content-start">
        <a href="" class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></a>
        <div class="aside-alert-link">
          <a href="" class="new" data-toggle="tooltip" title="You have 2 unread messages"><i data-feather="message-square"></i></a>
          <a href="" class="new" data-toggle="tooltip" title="You have 4 new notifications"><i data-feather="bell"></i></a>
          <a href="" data-toggle="tooltip" title="Sign out"><i data-feather="log-out"></i></a>
        </div>
      </div>
      <div class="aside-loggedin-user">
        <a href="#loggedinMenu" class="d-flex align-items-center justify-content-between mg-b-2" data-toggle="collapse">
          <h6 class="tx-semibold mg-b-0">Katherine Pechon</h6>
          <i data-feather="chevron-down"></i>
        </a>
        <p class="tx-color-03 tx-12 mg-b-0">Administrator</p>
      </div>
      <div class="collapse" id="loggedinMenu">
        <ul class="nav nav-aside mg-b-0">
          <li class="nav-item"><a href="" class="nav-link"><i data-feather="edit"></i> <span>Edit Profile</span></a></li>
          <li class="nav-item"><a href="" class="nav-link"><i data-feather="user"></i> <span>View Profile</span></a></li>
          <li class="nav-item"><a href="" class="nav-link"><i data-feather="settings"></i> <span>Account Settings</span></a></li>
          <li class="nav-item"><a href="" class="nav-link"><i data-feather="help-circle"></i> <span>Help Center</span></a></li>
          <li class="nav-item"><a href="" class="nav-link"><i data-feather="log-out"></i> <span>Sign Out</span></a></li>
        </ul>
      </div>
    </div><!-- aside-loggedin -->
    <ul class="nav nav-aside">
        <li><a href="{{route('dashboard')}}"><i class="nav-label"></i>Dashboard</a></li>

        @if(in_array('Usermanage', $enabled_module ))
            @if($role == "super_admin")
            <li class="nav-item with-sub {{ in_array($indexurl, array('role', 'user', 'employee', 'permission', 'department','designation')) ? 'active' : ''}} " >
                <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>User Management</span></a>

                <ul>
                    <li class='{{$indexurl == 'user' ? 'active' : ''}}'><a href="{{route('user.index')}}">User</a></li>
                    <li class='{{$indexurl == 'employee' ? 'active' : ''}}'><a href="{{route('employee.index')}}">Employee</a></li>
                    <li class='{{$indexurl == 'role' ? 'active' : ''}}'><a href="{{route('role.index')}}">Role</a></li>
                    <li class='{{$indexurl == 'permission' ? 'active' : ''}}'><a href="{{route('permission.index')}}">Permission</a></li>
                    <li class='{{$indexurl == 'department' ? 'active' : ''}}'><a href="{{route('department.index')}}">Department</a></li>
                    <li class='{{$indexurl == 'designation' ? 'active' : ''}}'><a href="{{route('designation.index')}}">Designation</a></li>
                    
                </ul>
            </li>
            @endif
        @endif

        @if(in_array('SEO', $enabled_module ))
        <li class="nav-item  {{ in_array($indexurl, array('seo-website', 'seo-task', 'daily-work', 'seo-work', 'seo-result','seo-task','import-data')) ? 'active' : ''}} with-sub">
            <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>SEO</span></a>
            <ul>
                @if(session()->get('utype') == "1")
                <li class='{{$indexurl == 'seo-website' ? 'active' : ''}}{{$indexurl == 'seo-task' ? 'active' : ''}}'><a href="{{route('workReport')}}" class="nav-link">General Settings</a></li>

                <li class='{{$indexurl == 'submission' ? 'active' : ''}}'><a href="{{route('submission.index')}}">Submission Url</a></li>
                
                <li class='{{$indexurl == 'daily-work' ? 'active' : ''}}'><a href="{{route('daily-work.index')}}">Daily Work</a></li>
                @else
                <li class='{{$indexurl == 'seo-work' ? 'active' : ''}}{{$indexurl == 'import-data' ? 'active' : ''}}'><a href="{{route('seo-work.index')}}">Work Report</a></li>
                <li class='{{$indexurl == 'seo-result' ? 'active' : ''}}'><a href="{{route('seo-result.index')}}">Monthly Result</a></li>
                @endif
                
            </ul>
        </li>
        @endif


        @if(in_array('Newsletter', $enabled_module ))
            @if($role == "super_admin")
            <li class="nav-item with-sub {{ in_array($indexurl, array('newsletter')) ? 'active' : ''}}">
                <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>CRM</span></a>
                <ul>
                    <li class='{{$indexurl == 'leads' ? 'active' : ''}}'><a href="{{route('leads.index')}}">Lead</a></li>
                    <li class='{{$indexurl == 'lead-setting' ? 'active' : ''}}'><a href="{{route('lead-setting.index')}}">Lead Setting</a></li>
                    <li class='{{$indexurl == 'customer' ? 'active' : ''}}'><a href="{{route('customer.index')}}">Customer</a></li>
                    <li class='{{$indexurl == 'quotation' ? 'active' : ''}}'><a href="{{route('quotation.index')}}">Quotation</a></li>
                </ul>
            </li>
            @endif
        @endif

        @if(in_array('Newsletter', $enabled_module ))
            @if($role == "super_admin")
            <li class="nav-item with-sub">
                <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>Newsletter</span></a>
                <ul>
                    <li><a href="{{route('sender-list.index')}}">Setting</a></li>
                    <li class='{{$indexurl == 'template-list' ? 'active' : ''}}{{$indexurl == 'template-lists' ? 'active' : ''}}'><a href="{{route('template-group-list.index')}}">Template</a></li>
                    <li class='{{$indexurl == 'contact-list' ? 'active' : ''}}{{$indexurl == 'importfile' ? 'active' : ''}}'><a href="{{route('contact-group-list.index')}}">Contacts</a></li>
                    <li class='{{$indexurl == 'campaign' ? 'active' : ''}}'><a href="{{route('campaign.index')}}">Campaign</a></li>
                </ul>
            </li>
            @endif
        @endif




        <li class="nav-label mg-t-25">Add On</li>

        @if(in_array('AddOnManager', $enabled_module ))
        <li class="nav-item">
         <a href="{{route('add-on-manager.index')}}" class="nav-link">Add On Manager</a>
        </li>
        @endif

        @if(in_array('AddOnManager', $enabled_module ))
        <li class="nav-item with-sub {{ in_array($indexurl, array('pc-categories')) ? 'active' : ''}} with-sub">
            <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>PapaChina Product</span></a>
            <ul>
                <li class='{{$indexurl == 'pc-categories' ? 'active' : ''}}'><a href="{{route('pc-categories.index')}}">Category</a></li>

                <li class='{{$indexurl == 'pc-products' ? 'active' : ''}}'><a href="{{route('pc-products.index')}}">Product</a></li>
                
            </ul>
        </li>
        @endif


        

        @if($role == "super_admin")
        <li class="nav-label mg-t-25">Setting</li>
        <li class="nav-item with-sub">
            <a href="javascript:void(0)" class="nav-link"><i data-feather="user"></i> <span>General Setting</span></a>
               <ul>
                   <li><a href="{{route('app-setting-group.index')}}">App Setting List</a></li>
                   <li><a href="{{route('app-settings.index')}}">App Setting </a></li>
                   <li><a href="{{route('custom-form.index')}}">Custom Form</a></li>
                   <li><a href="{{route('module-management.index')}}">Module</a></li>
                   <li><a href="{{route('email-group.index')}}">Email Templates</a></li>
               </ul>
           </div>
       </li>
       @endif


    </ul>
  </div>


