<?php
return [
    'dashboard' => 'Приборная доска',
    'welcome' => 'С возвращением, Кристина!';
    
];